import QrScannerPage from './QrScannerPage';
import './App.css';

function App() {
  return (
    <div className="App">
      <QrScannerPage />
    </div>
  );
}

export default App
